Mambo City server resource pack

What is inside:
- A custom bitmap glyph for the private-use character U+E000
- The glyph renders a neon "MAMBO CITY / SURVIVAL" title
- Extra glyphs for sidebar icons and divider

Glyph map:
- U+E000 = title
- U+E001 = divider
- U+E002 = AR currency icon
- U+E003 = ping icon
- U+E004 = online icon
- U+E005 = kills icon
- U+E006 = deaths icon
- U+E007 = time icon

How to use in TAB:
1. Keep this pack as a .zip on a direct-download URL.
2. Add it to server.properties using resource-pack and resource-pack-sha1.
3. In TAB scoreboard or header text, paste these characters as needed:
   - title: 
   - divider: 
   - ar: 
   - ping: 
   - online: 
   - kills: 
   - deaths: 
   - time: 

Example TAB scoreboard title:
  ""

Notes:
- This is a first-pass title pack. We can add more glyphs later for icons, separators, or a cleaner logo.
- The character above is U+E000. If it does not paste correctly, copy it from here again.

Legacy spear compatibility:
- This pack adds a legacy spear skin on top of TRIDENT using custom_model_data = 120041.
- Normal tridents are not changed.

Example give command (Paper 1.21+ component syntax):
/give @p trident[custom_model_data=120041,custom_name='{"text":"Spear","italic":false,"color":"aqua"}']

Legacy compatibility set (for older Java clients):
- Spear fallback: TRIDENT + cmd 120041
- Mace fallback: NETHERITE_AXE + cmd 120101
- Wind Charge fallback: SNOWBALL + cmd 120102
- Breeze Rod fallback: BLAZE_ROD + cmd 120103
- Heavy Core fallback: NETHER_STAR + cmd 120104
- Trial Key fallback: TRIPWIRE_HOOK + cmd 120105
- Ominous Trial Key fallback: TRIPWIRE_HOOK + cmd 120106

Ready test commands:
/give @p trident{CustomModelData:120041,display:{Name:'{"text":"Spear","italic":false,"color":"aqua"}'}} 1
/give @p netherite_axe{CustomModelData:120101,display:{Name:'{"text":"Mace","italic":false,"color":"gray"}'}} 1
/give @p snowball{CustomModelData:120102,display:{Name:'{"text":"Wind Charge","italic":false,"color":"aqua"}'}} 1
/give @p blaze_rod{CustomModelData:120103,display:{Name:'{"text":"Breeze Rod","italic":false,"color":"green"}'}} 1
/give @p nether_star{CustomModelData:120104,display:{Name:'{"text":"Heavy Core","italic":false,"color":"light_purple"}'}} 1
/give @p tripwire_hook{CustomModelData:120105,display:{Name:'{"text":"Trial Key","italic":false,"color":"gold"}'}} 1
/give @p tripwire_hook{CustomModelData:120106,display:{Name:'{"text":"Ominous Trial Key","italic":false,"color":"dark_purple"}'}} 1
